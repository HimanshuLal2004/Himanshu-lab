﻿using MySqlConnector;
using System;

namespace _1_Make_Connection_To_MariaDB
{
    internal class Program
    {
        static void Main(string[] args)
        {
            MySqlConnectionStringBuilder builder =
              new MySqlConnectionStringBuilder
              {
                  Server = "localhost",
                  UserID = "root",
                  Password = "OOP2@",
                  Database = "demo1",
              };

            MySqlConnection connection =
              new MySqlConnection(builder.ConnectionString);

            connection.Open();

            
            string sql = "SELECT * FROM students";

            string sql = "SELECT id, name FROM students";


            
            MySqlCommand command = new MySqlCommand(sql, connection);

            
            using (MySqlDataReader reader = command.ExecuteReader())
            {
                while (reader.Read())
                {
                    
                    int id = reader.GetInt32(0);

                    
                    string name = reader.GetString(1);

                    
                    double gpa = reader.GetDouble(2);


                    Console.WriteLine($"{id,-5} {name,-20} {gpa,-10}");
                }
            }



            connection.Close();

            Console.WriteLine("Database connection is now finsih");
        }
    }
}
