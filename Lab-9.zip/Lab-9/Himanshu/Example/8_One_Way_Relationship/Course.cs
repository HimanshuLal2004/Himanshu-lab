﻿public class Course
{
    // Properties for Course entity
    public int Id { get; set; }
    public string CourseName { get; set; }

    // Constructor
    public Course(int id, string courseName)
    {
        Id = id;
        CourseName = courseName;
    }
}