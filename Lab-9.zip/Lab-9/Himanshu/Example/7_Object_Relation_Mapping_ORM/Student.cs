﻿public class Student
{
    public int Id { get; set; }
    public string Name { get; set; }
    public double GPA { get; set; }
    public string Program {  get; set; }

    public Student(int id, string name, double gpa, string program)
    {
        Id = id;
        Name = name;
        GPA = gpa;
        Program = program;
    }
}
