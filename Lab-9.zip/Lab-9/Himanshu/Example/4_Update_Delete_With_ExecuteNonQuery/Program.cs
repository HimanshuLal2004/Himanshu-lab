﻿using MySqlConnector;
using System;

namespace _1_Make_Connection_To_MariaDB
{
    internal class Program
    {
        static void Main(string[] args)
        {
            MySqlConnectionStringBuilder builder =
              new MySqlConnectionStringBuilder
              {
                  Server = "localhost",
                  UserID = "root",
                  Password = "OOP2@",
                  Database = "demo1",
              };

            MySqlConnection connection =
              new MySqlConnection(builder.ConnectionString);

            connection.Open();

            string sql = "UPDATE student SET gpa = 3.5 WHERE id = 1";

            MySqlCommand command = new MySqlCommand(sql, connection);

            int affected = command.ExecuteNonQuery();

            if (affected > 0)
            {
                Console.WriteLine($"{affected} row/s affected");
            }
            else
            {
                Console.WriteLine("Nothing has been updated because data does not exist");
            }

            connection.Close();

            Console.WriteLine("Database connection is closed.");
        }
    }
}
