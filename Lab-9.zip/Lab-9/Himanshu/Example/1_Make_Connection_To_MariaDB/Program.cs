﻿
using MySqlConnector;

namespace _1_Make_Connection_To_MariaDB
{
    internal class Program
    {
        static void Main(string[] args)
        {
            
            MySqlConnectionStringBuilder builder =
              new MySqlConnectionStringBuilder
              {
                  
                  Server = "localhost",
                  
                  UserID = "root",
                  
                  Password = "OOP2@",
                  
                  Database = "demo1",
              };

            
            MySqlConnection connection =
              new MySqlConnection(builder.ConnectionString);

            
            connection.Open();

            Console.WriteLine("Database connection is open.");

            
            connection.Close();

            Console.WriteLine("Database connection is closed.");
        }
    }
}
